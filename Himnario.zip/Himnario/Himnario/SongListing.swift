//
//  SongListing.swift
//  Himnario
//
//  Created by Student 12 on 7/19/24.
//

import SwiftUI

struct SongListing: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    SongListing()
}
